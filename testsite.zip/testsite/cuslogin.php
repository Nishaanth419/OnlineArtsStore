<?php
    if(isset($_POST['submit']))
    {
      $password = $_POST['password'];
      $email = $_POST['email'];
      $Hno = $_POST['HousingNo'];
      $fname = $_POST['fname'];
      $lname = $_POST['lname'];
      $DOB = $_POST['date'];
      $pno = $_POST['pno'];
    
        $host = "localhost";
        $username = "root";
        $pass = "";
        $dbname = "customer";

        
        $con = mysqli_connect($host, $username, $pass, $dbname);
        $con1 = mysqli_connect($host, $username, $pass, $dbname);
        if (!$con)
        {
            die("Connection failed!" . mysqli_connect_error());
        }
      
        $sql = "INSERT INTO customer (Cust_Email, First_name, Last_name, Housing_no, DOB,C_Password) VALUES ('$email', '$fname', '$lname', '$Hno', '$DOB','$password')";
        $sql1 = "INSERT INTO customer_cust_phoneno (Cust_Email,Cust_PhoneNO) VALUES ('$email','$pno')";
        $rs = mysqli_query($con, $sql);
        $rs1 = mysqli_query($con1, $sql1);
        ?>
        <body style="background-color: #899ba1;
    background-image: linear-gradient(315deg, #000000 0%, #2d343d 74%);">
    <?php
        if($rs && $rs1)
        {
            echo "<h1 style='color:white;'><center>Successfully saved </h1></center>";
        }
      
        mysqli_close($con);
    }
   
?>
</body>




