<?php
    if(isset($_POST['submit']))
    {
      $feedback = $_POST['feedback'];
      $email = $_POST['email'];
      $Sugg = $_POST['Sugg'];
      $Compl = $_POST['Compl'];
      
    
        $host = "localhost";
        $username = "root";
        $pass = "";
        $dbname = "customer";

        
        
        $con1 = mysqli_connect($host, $username, $pass, $dbname);
        if (!$con1)
        {
            die("Connection failed!" . mysqli_connect_error());
        }
      
        
        $sql1 = "INSERT INTO feedback (Cust_Email,Feedname,Suggestions, Complaints ) VALUES ('$email','$feedback','$Sugg', '$Compl')";
        
        $rs1 = mysqli_query($con1, $sql1);
        ?>
        <body style="background-color: #899ba1;
    background-image: linear-gradient(315deg, #000000 0%, #2d343d 74%);">
        <?php
        if($rs1)
        {
            echo "<h1 style='color:white;'><center>Feedback sent </h1></center>";
        }
      
        mysqli_close($con1);
    }
   
?>