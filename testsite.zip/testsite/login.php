<?php
        $host = "localhost";
        $username = "root";
        $pass = "";
        $dbname = "customer";     
        $con = mysqli_connect($host, $username, $pass, $dbname);
        $email = $_POST['email']; 
        $password = $_POST['password'];      
        $email = stripcslashes($email);  
        $password = stripcslashes($password);  
        $email = mysqli_real_escape_string($con, $email);  
        $password = mysqli_real_escape_string($con, $password);  
        $sql = "select *from customer where Cust_Email  = '$email' and C_Password = '$password'";  
        $result = mysqli_query($con, $sql);  
        $row = mysqli_fetch_array($result, MYSQLI_ASSOC);  
        $count = mysqli_num_rows($result);    
        if($count == 1)
        {  
            echo "<h1 style='color:white;'><center> Login successful </center></h1>"; 
        
?>
<!DOCTYPE html>
<html>
<head>
<style>
.button {
  display: inline-block;
  border-radius: 4px;
  background-color: #f4511e;
  border: none;
  color: #FFFFFF;
  text-align: center;
  font-size: 28px;
  padding: 20px;
  width: 500px;
  transition: all 0.5s;
  cursor: pointer;
  margin: 5px;
}

.button span {
  cursor: pointer;
  display: inline-block;
  position: relative;
  transition: 0.5s;
}

.button span:after {
  content: '\00bb';
  position: absolute;
  opacity: 0;
  top: 0;
  right: -20px;
  transition: 0.5s;
}

.button:hover span {
  padding-right: 25px;
}

.button:hover span:after {
  opacity: 1;
  right: 0;
}
</style>
</head>
            
            <body style="background-color: #899ba1;
    background-image: linear-gradient(315deg, #000000 0%, #2d343d 74%);"><form method ="post" ID="art" action="artstock.html">
<center><tr><td><input class="button" type="submit" id="submit" name="Submit" value="SHOP HERE!!!!" ></td></center>
    </form>
    <?php
        }
        ?>
<?php
        if($count != 1)  {
        echo " <body style='background-color: #899ba1;
        background-image: linear-gradient(315deg, #000000 0%, #2d343d 74%);'> <h1 style='color:white;'><center> Login failed Invaild USER ID or PASSWORD </center></h1>"; 
        }
?>  


