<body style='background-color:#F7CAC9';>
<?php
    if(isset($_POST['submit']))
    {
      
      $email = $_POST['email'];
      $Hno = $_POST['hno'];
      $ARTID = $_POST['ARTID'];
      $pdate = $_POST['Pay-Date'];
      $date = $_POST['date'];
      $pmode = $_POST['Pay-Mode'];
      $amt = $_POST['Amount'];
      $pid = $_POST['PayID'];
      
    
        $host = "localhost";
        $username = "root";
        $pass = "";
        $dbname = "customer";

        
        $con3 = mysqli_connect($host, $username, $pass, $dbname);
        $con4 = mysqli_connect($host, $username, $pass, $dbname);
        if (!$con3)
        {
            die("Connection failed!" . mysqli_connect_error());
        }
        $sql3 = "INSERT INTO payment (Cust_Email,Pay_Date,Pay_Mode,Total_pay_amt,Pay_ID,Pay_status) VALUES ('$email','$pdate','$pmode','$amt','$pid','done')";
        $sql2 = "INSERT INTO `order` (Order_Date, Cust_Email, Art_ID, Housing_no,Pay_ID ) VALUES ('$date', '$email', '$ARTID', '$Hno','$pid')";
        $sql1="update art_stork set Quantity=Quantity-1 where Art_ID='$ARTID'";
        $rs3 = mysqli_query($con4, $sql3);
        $rs2 = mysqli_query($con3, $sql2);
        $rs4 = mysqli_query($con3, $sql1);
        
        if($rs2 && $rs3 && $rs4)
        {
            echo "<h1 style='background-color:#F7CAC9';><bold><center>Thank You, If u have any Suggestions or Complaints report it on contact page in Home</center></bold></h1>";
            $records = mysqli_query($con4,"select * from payment where Pay_ID= '$pid'"); // fetch data from database

while($data = mysqli_fetch_array($records))
{
   

?>
<center><h2 style='background-color:#F7CAC9';>PAYMENT Details</h2>

<table border="2">
  <tr>
    <td>Pay_ID</td>
    <td>Cust_Email</td>
    <td>Pay_Date</td>
    <td>Pay_Mode</td>
    <td>Total_pay_amt</td>
    <td>Pay_status</td>
    
  </tr>

  <tr><td><?php echo $data['Pay_ID']; ?></td>
    <td><?php echo $data['Cust_Email']; ?></td>
    <td><?php echo $data['Pay_Date']; ?></td>
    <td><?php echo $data['Pay_Mode']; ?></td>
    <td><?php echo $data['Total_pay_amt']; ?></td>
    <td><?php echo $data['Pay_status']; ?></td>
  </tr>	</center>
  
<?php
}
?>
</table>
<h2><center>The Order will be deliveried within 5 working days. </center></h2>
<h2><center>The Admins will contact you via mail for furthur information about the Delivery.</center></h2>
<h2><center>The cancelation of the order can be done once you get the item.</center></h2>
<h2><center>The amount will be refunded with 24 hrs</center></h2>
<?php mysqli_close($con4); // Close connection 

        }
      
        mysqli_close($con3);
    }
   
?>
</body>
