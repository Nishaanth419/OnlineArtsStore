<?php
    if(isset($_POST['submit']))
    {
      $Order_ID = $_POST['Order_ID'];
      $Status = $_POST['Status'];
      $Delivery_Date = $_POST['Delivery_Date'];
      $Updated_Date = $_POST['Updated_Date'];
      
        $host = "localhost";
        $username = "root";
        $pass = "";
        $dbname = "customer";

        
        $con = mysqli_connect($host, $username, $pass, $dbname);
        if (!$con)
        {
            die("Connection failed!" . mysqli_connect_error());
        }
      
        $sql = "INSERT INTO order_update (Status, Delivery_Date, Order_ID , Updated_Date) VALUES ('$Status', '$Delivery_Date', '$Order_ID', '$Updated_Date')";
     
        $rs = mysqli_query($con, $sql);
        
        
        if($rs)
        {
            echo "<center><h1 style='color:white;'>Successfully Updated</h1></center>";
        }
      
        mysqli_close($con);
    }
   
?>
<style>
.button {
  display: inline-block;
  border-radius: 4px;
  background-color: #f4511e;
  border: none;
  color: #FFFFFF;
  text-align: center;
  font-size: 28px;
  padding: 20px;
  width: 500px;
  transition: all 0.5s;
  cursor: pointer;
  margin: 5px;
}

.button span {
  cursor: pointer;
  display: inline-block;
  position: relative;
  transition: 0.5s;
}

.button span:after {
  content: '\00bb';
  position: absolute;
  opacity: 0;
  top: 0;
  right: -20px;
  transition: 0.5s;
}

.button:hover span {
  padding-right: 25px;
}

.button:hover span:after {
  opacity: 1;
  right: 0;
}
</style>
<body style="background-color: #899ba1;
    background-image: linear-gradient(315deg, #000000 0%, #2d343d 74%);">
<form  method ="post" ID="art" action="updatedinfo.php">
    <center>
<tr><td><input class="button"type="submit" id="submit" name="Submit" value="VIEW UPDATED INFORMATION" ></td>
    </form>
</center>